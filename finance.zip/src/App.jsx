import { BrowserRouter, Routes, Route } from "react-router-dom";
import LoginPage from "./pages/LoginPage";
import { AppProvider } from "./context/AppContext";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import FinanacePage from "./pages/FinancePage";
import RevenueReportPage from "./pages/RevenueReportPage";
import AgingReportPage from "./pages/AgingReportPage";
import Collection1 from "./pages/Collection1";
import ActualCashflowReportPage from "./pages/ActualCashflowReportPage";

const App = () => {
  return (
    <AppProvider>
      <ToastContainer />
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/" element={<FinanacePage />} />
          <Route path="/reports/revenue" element={<RevenueReportPage />} />
          <Route path="/reports/aging" element={<AgingReportPage />} />
          <Route path="/reports/collection1" element={<Collection1 />} />
          <Route
            path="/reports/actual_cashflow"
            element={<ActualCashflowReportPage />}
          />
        </Routes>
      </BrowserRouter>
    </AppProvider>
  );
};
export default App;
